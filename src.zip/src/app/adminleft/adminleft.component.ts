import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminleft',
  templateUrl: './adminleft.component.html',
  styleUrls: ['./adminleft.component.css']
})
export class AdminleftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
