import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageonboarding',
  templateUrl: './manageonboarding.component.html',
  styleUrls: ['./manageonboarding.component.css']
})
export class ManageonboardingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
