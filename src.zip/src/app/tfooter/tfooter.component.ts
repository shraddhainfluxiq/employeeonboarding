import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tfooter',
  templateUrl: './tfooter.component.html',
  styleUrls: ['./tfooter.component.css']
})
export class TfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
